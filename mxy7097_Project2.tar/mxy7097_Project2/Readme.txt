Project 2 Assignment 1:

Used slides and given code to compile a working multithread.

Project 2 Assignment 2:

Used pthread conditionals.